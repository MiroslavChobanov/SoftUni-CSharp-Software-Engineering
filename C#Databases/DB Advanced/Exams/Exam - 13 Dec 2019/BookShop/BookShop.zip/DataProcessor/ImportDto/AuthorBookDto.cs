﻿namespace BookShop.DataProcessor.ImportDto
{
    public class AuthorBookDto
    {
        public int Id { get; set; }
    }
}