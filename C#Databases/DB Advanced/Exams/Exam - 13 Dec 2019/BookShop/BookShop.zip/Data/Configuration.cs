﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=(localdb)\MSSQLLocalDB;Database=BookShop;Trusted_Connection=True";
    }
}